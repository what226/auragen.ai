#!/usr/bin/env node
/*
 * AuraGen AI - local host server (Node.js, no npm install needed)
 *
 * Run:   node server.js
 * Then open http://localhost:8000 in your browser. Ctrl+C to stop.
 */
const http = require("http");
const fs = require("fs");
const path = require("path");

const ROOT = __dirname;
const START_PORT = parseInt(process.argv[2], 10) || 8000;

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".md": "text/markdown; charset=utf-8",
};

const server = http.createServer((req, res) => {
  let urlPath = decodeURIComponent(req.url.split("?")[0]);
  if (urlPath === "/") urlPath = "/index.html";

  // prevent path traversal
  const filePath = path.join(ROOT, path.normalize(urlPath));
  if (!filePath.startsWith(ROOT)) {
    res.writeHead(403);
    return res.end("Forbidden");
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { "Content-Type": "text/html" });
      return res.end("<h1>404 - Not found</h1>");
    }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      "Content-Type": MIME[ext] || "application/octet-stream",
      "Cache-Control": "no-store",
    });
    res.end(data);
    console.log("  200  " + urlPath);
  });
});

function listen(port) {
  server.listen(port);
}

server.on("error", (e) => {
  if (e.code === "EADDRINUSE") {
    console.log("  port " + START_PORT + " busy, trying " + (START_PORT + 1));
    server.listen(START_PORT + 1);
  } else {
    throw e;
  }
});

server.on("listening", () => {
  const port = server.address().port;
  console.log("\n  AuraGen AI is running");
  console.log("  -> http://localhost:" + port + "/");
  console.log("  (serving " + ROOT + ")");
  console.log("  Press Ctrl+C to stop.\n");
});

listen(START_PORT);
