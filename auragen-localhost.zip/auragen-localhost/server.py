#!/usr/bin/env python3
"""
AuraGen AI - local host server (zero dependencies, Python 3 only)

Run:
    python server.py
then open the printed URL (http://localhost:8000) in your browser.

It serves index.html and auto-opens your browser. Press Ctrl+C to stop.
"""
import http.server
import socketserver
import os
import sys
import webbrowser
from functools import partial

DEFAULT_PORT = 8000
ROOT = os.path.dirname(os.path.abspath(__file__))


class Handler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        # don't cache during local dev so edits show up immediately
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def log_message(self, fmt, *args):
        sys.stdout.write("  %s\n" % (fmt % args))


def pick_port(start):
    """Return the first free port at/after `start`."""
    import socket
    for port in range(start, start + 20):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    return start


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else pick_port(DEFAULT_PORT)
    handler = partial(Handler, directory=ROOT)
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", port), handler) as httpd:
        url = "http://localhost:%d/" % port
        print("\n  AuraGen AI is running")
        print("  -> %s" % url)
        print("  (serving %s)" % ROOT)
        print("  Press Ctrl+C to stop.\n")
        try:
            webbrowser.open(url)
        except Exception:
            pass
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n  Stopped.")


if __name__ == "__main__":
    main()
