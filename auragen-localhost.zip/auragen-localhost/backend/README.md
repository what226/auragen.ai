# AuraGen AI

An all-in-one AI studio for generating **images and videos** — plus a prompt studio, creative tools, user/admin dashboards, subscriptions, an affiliate program, and social publishing.

This repository ships in two layers, and it's important to be clear about what each one is:

| Layer | File(s) | State |
|---|---|---|
| **Working front-end prototype** | `index.html` | ✅ Fully functional, self-contained, runs in any browser |
| **Backend blueprint** | `prisma/schema.prisma`, `.env.example`, this README | 📐 Production architecture + data model — **scaffolding to build onto, not a running server** |

> ### Read this first — honest scope
> The brief asked for a *complete, production-ready full-stack system* with live Stripe **and** Razorpay payments, real OAuth, wired OpenAI/Gemini/Replicate calls, admin tooling, affiliate payouts, and social publishing. That is genuinely a multi-month engineering effort spanning hundreds of files, and **no one can truthfully hand you a secure, deployable version of it in a single step.** Shipping untested payment/auth code that *looks* production-ready would be worse than useless — it's a security liability.
>
> So this delivers the two things that are actually useful right now: a **polished front-end you can click through and demo today**, and an **accurate backend blueprint** (schema + route map + deployment plan) so the server can be built on solid foundations. Every screen in the spec exists in the prototype. Where something needs a real server, it's listed below under *Needs wiring*.

---

## 1. The prototype (`index.html`)

Open the file in any modern browser — no build step, no dependencies, no install.

**What's genuinely live:**
- **Real image generation** via the keyless [Pollinations](https://pollinations.ai) endpoint (text-to-image with model, style, aspect ratio, negative prompt, batch count, hi-res toggle).
- Full SPA navigation across **Landing, Image Studio, Video Studio, Prompt Studio, Tools, User Dashboard, Admin Console**.
- Working **prompt enhancer**, templates, trending prompts, copy/save.
- **Favorites, history, lightbox, downloads**, credit accounting — persisted via `localStorage` (with an in-memory fallback so it also runs inside sandboxed preview iframes).
- **Pricing** with monthly/yearly toggle, **checkout modal** (Stripe/Razorpay UI + working coupon codes `AURA20`, `LAUNCH50`, `CREATOR`), **auth modal** (login/register/forgot/Google), **AI chatbot** assistant, toasts, fully **responsive** dark glassmorphism UI.

**What's simulated (clearly, on purpose):**
- **Video generation** renders a representative still frame with motion styling. Real text-to-video needs a paid GPU model (see *Needs wiring*).
- **Auth / payments / admin data** are client-side mocks — they demonstrate the exact flows and UI the backend will drive, with seeded data.
- If external images are blocked (e.g. a strict preview sandbox), every image falls back to a generated gradient so the UI never breaks. Open the file in a normal browser tab for live generation.

The design evolves the original `AuraGen___AI_Image___Video_Generator.html` — same palette, fonts, and glassmorphism identity, expanded into a full product.

---

## 2. Backend blueprint

### Tech stack (as specified)
- **Frontend:** Next.js (App Router) · React · TypeScript · Tailwind CSS
- **Backend:** Node.js · Express (or Next.js route handlers) · TypeScript
- **Database:** PostgreSQL · Prisma ORM
- **Auth:** JWT (access + refresh) · Google OAuth
- **Media:** Cloudinary
- **AI:** OpenAI · Gemini · Replicate
- **Payments:** Stripe (global) · Razorpay (India)
- **Infra:** Redis (rate limiting + job queue)

The full data model is in **`prisma/schema.prisma`** — 25+ models covering users, OAuth, sessions, plans, subscriptions, payments, credit ledger, coupons, AI models, generations, favorites, saved/trending prompts, affiliates/commissions/payouts, social accounts/posts, API keys, moderation, support tickets, and site settings.

### Suggested project layout
```
auragen/
├─ web/                  # Next.js front-end (port the prototype's screens to components)
├─ api/                  # Express API (or Next.js route handlers)
│  ├─ routes/
│  ├─ services/          # stripe, razorpay, openai, replicate, cloudinary, credits
│  ├─ middleware/        # auth (JWT), rateLimit, errorHandler, validate
│  └─ workers/           # BullMQ workers for async generation jobs
├─ prisma/
│  ├─ schema.prisma      # ← included
│  └─ seed.ts
└─ .env                  # from .env.example (included)
```

### Feature → API route map

| Feature | Method & route | Notes |
|---|---|---|
| Register | `POST /api/auth/register` | hash with argon2/bcrypt, grant 50 credits |
| Login | `POST /api/auth/login` | issue access+refresh JWT |
| Google OAuth | `GET /api/auth/google` → `/callback` | upsert `OAuthAccount` |
| Refresh / Logout | `POST /api/auth/refresh` · `/logout` | rotate refresh token in `Session` |
| Forgot / Reset | `POST /api/auth/forgot` · `/reset` | `PasswordReset` + email |
| Profile | `GET/PATCH /api/me` | name, locale, avatar |
| Generate image | `POST /api/generate/image` | check credits → enqueue → Replicate/OpenAI → Cloudinary → debit `CreditTransaction` |
| Generate video | `POST /api/generate/video` | async job; poll `GET /api/generate/:id` |
| Tools | `POST /api/tools/{upscale,bg-remove,face-swap,avatar,logo,thumbnail}` | model per `AiModel` |
| History / favorites | `GET /api/generations` · `POST /api/favorites` | paginated |
| Prompt enhance | `POST /api/prompt/enhance` | OpenAI/Gemini completion |
| Saved / trending | `GET/POST /api/prompts` · `GET /api/prompts/trending` | |
| Plans / checkout | `GET /api/plans` · `POST /api/checkout` | Stripe Checkout or Razorpay Order |
| Webhooks | `POST /api/webhooks/stripe` · `/razorpay` | **source of truth** for sub state; verify signatures |
| Subscription mgmt | `GET /api/subscription` · `POST /api/subscription/cancel` | |
| Coupons | `POST /api/coupons/validate` (admin CRUD under `/api/admin`) | |
| Affiliate | `GET /api/affiliate` · `POST /api/affiliate/withdraw` | commissions credited on referred payment |
| Social connect | `GET /api/social/:provider/connect` · `POST /api/social/publish` | OAuth per platform |
| API keys | `GET/POST/DELETE /api/keys` | store hash, show prefix once |
| Admin | `GET /api/admin/{stats,users,subscriptions,models,moderation,tickets,coupons,settings}` | role-gated `ADMIN` |

### Credit system (the core money loop)
Every generation: **verify balance → create `Generation` (QUEUED) → run provider job → on success debit via `CreditTransaction` and store running `balance`**. Refills happen on the subscription webhook's `invoice.paid`. Keep credits server-authoritative — never trust the client.

### Security checklist (do not skip)
- Hash passwords (argon2id/bcrypt); never log secrets.
- Verify **Stripe/Razorpay webhook signatures**; treat webhooks as the billing source of truth.
- Short-lived access JWT + rotating refresh tokens in `Session`; httpOnly cookies.
- Rate-limit auth + generation endpoints (Redis).
- Validate every input (zod); enforce role checks on all `/api/admin/*`.
- Run generations through a moderation/safety filter → `ModerationItem`.
- Store only **hashes** of API keys.

---

## 3. Deployment

| Component | Recommended host |
|---|---|
| Next.js front-end | **Vercel** |
| Express API + workers | **Railway** or **Render** |
| PostgreSQL | **Neon**, **Supabase**, or Railway |
| Redis | Upstash / Railway |
| Media | Cloudinary |

```bash
# 1. install & configure
npm install
cp .env.example .env        # fill in real keys

# 2. database
npx prisma migrate deploy
npx prisma db seed          # plans, AI models, trending prompts

# 3. run
npm run dev                 # web + api
```
Point Stripe/Razorpay webhooks at your deployed `/api/webhooks/*`. Set the same env vars in each host's dashboard.

---

## 4. Build order (realistic path to production)
1. **Auth** — register/login/Google/refresh + `me`. 
2. **Generation + credits** — wire Replicate/OpenAI, Cloudinary upload, credit ledger. 
3. **Billing** — Stripe Checkout + webhooks first, then Razorpay; refills on `invoice.paid`. 
4. **Dashboards** — read endpoints behind the existing UI. 
5. **Admin** — role-gated CRUD + analytics aggregates. 
6. **Affiliate, social, API keys, extra tools** — layer on once the core loop is solid.

Port the prototype's screens into Next.js components one route at a time — the markup, state shape, and interactions are already designed and working in `index.html`.

---

*Front-end: ready to use today. Backend: a faithful, secure blueprint to build the real thing — no fake "production-ready" claims.*
