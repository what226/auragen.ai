# ▶ Run AuraGen AI on localhost

Everything is bundled in this folder. Pick **one** of the options below — each starts a local web server and serves the app at `http://localhost:8000`.

> You only need a server because browsers restrict some features when a page is opened directly as a `file://`. Serving over `http://localhost` makes the app behave exactly like it would in production. (You *can* also just double-click `index.html` — most things work, but a local server is recommended.)

---

## Option A — Python (no install, works everywhere)
Python 3 ships on macOS/Linux and is a one-click install on Windows.

```bash
python server.py
```
(Windows: use `python server.py` · macOS/Linux: maybe `python3 server.py`)

It prints a URL and opens your browser automatically. **Done.**

### Even simpler (no script):
```bash
python -m http.server 8000
```
then open <http://localhost:8000> yourself.

---

## Option B — Node.js
```bash
node server.js
```
or
```bash
npm start
```
No `npm install` needed — the server uses only built-in Node modules.

---

## Option C — One-liner with npx (if you have Node)
```bash
npx serve .
```

---

## What you'll see
- A full AuraGen AI front-end: landing page, Image Studio (live generation), Video Studio, Prompt Studio, Tools, User Dashboard, Admin Console, auth & checkout modals, AI chatbot.
- **Image generation is live** via the keyless Pollinations endpoint, so you'll need an internet connection for images to render. Everything else works offline.

## Stop the server
Press `Ctrl + C` in the terminal.

## Change the port
```bash
python server.py 3000      # or
node server.js 3000
```

---

## What's in this folder
```
auragen-localhost/
├─ index.html        ← the app (self-contained: all CSS + JS inline)
├─ server.py         ← Python local server  (Option A)
├─ server.js         ← Node local server    (Option B)
├─ package.json      ← enables `npm start`
├─ START_HERE.md     ← this file
└─ backend/          ← backend blueprint (not run by the local server)
   ├─ README.md      ← architecture, API route map, deployment plan
   ├─ schema.prisma  ← full PostgreSQL data model (Prisma)
   └─ .env.example   ← environment variables template
```

The `backend/` files are the production blueprint for the real server (auth, payments, AI APIs, database). They are **reference material** — the localhost server above only serves the front-end. See `backend/README.md` for how to build the live backend.
