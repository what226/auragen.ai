'use client';

import React, { useState, FC } from 'react';
import { motion, Variants } from 'framer-motion';
import {
  Scissors,
  Search,
  ArrowRightLeft,
  User,
  Wand2,
  Frame,
  LucideIcon,
} from 'lucide-react';

// Type definitions
interface Tool {
  id: number;
  title: string;
  description: string;
  icon: LucideIcon;
  badge?: 'LIVE' | 'PRO' | 'NEW';
  badgeColor?: string;
  gradient: string;
  borderGlow: string;
}

interface CreativeToolsSectionProps {
  onToolClick?: (toolId: number) => void;
  showCTA?: boolean;
  animated?: boolean;
}

// Tool configuration with type safety
const TOOLS_CONFIG: Tool[] = [
  {
    id: 1,
    title: 'Background Remover',
    description: 'Cut any subject out cleanly with one click.',
    icon: Scissors,
    badge: 'LIVE',
    badgeColor: 'from-emerald-500 to-teal-500',
    gradient: 'from-emerald-600 via-teal-600 to-cyan-600',
    borderGlow: 'shadow-emerald-500/20',
  },
  {
    id: 2,
    title: 'Image Upscaler',
    description: 'Enhance and upscale up to 4× without losing detail.',
    icon: Search,
    badge: 'PRO',
    badgeColor: 'from-purple-500 to-pink-500',
    gradient: 'from-purple-600 via-pink-600 to-rose-600',
    borderGlow: 'shadow-purple-500/20',
  },
  {
    id: 3,
    title: 'Face Swap',
    description: 'Swap faces between photos realistically and safely.',
    icon: ArrowRightLeft,
    badge: 'PRO',
    badgeColor: 'from-blue-500 to-cyan-500',
    gradient: 'from-blue-600 via-cyan-600 to-teal-600',
    borderGlow: 'shadow-blue-500/20',
  },
  {
    id: 4,
    title: 'AI Avatar Generator',
    description: 'Turn a selfie into dozens of styled avatars.',
    icon: User,
    badge: 'NEW',
    badgeColor: 'from-pink-500 to-rose-500',
    gradient: 'from-pink-600 via-rose-600 to-red-600',
    borderGlow: 'shadow-pink-500/20',
  },
  {
    id: 5,
    title: 'AI Logo Generator',
    description: 'Brand-ready logos from a single description.',
    icon: Wand2,
    badge: 'NEW',
    badgeColor: 'from-orange-500 to-yellow-500',
    gradient: 'from-orange-600 via-yellow-600 to-amber-600',
    borderGlow: 'shadow-orange-500/20',
  },
  {
    id: 6,
    title: 'Thumbnail Generator',
    description: 'Scroll-stopping YouTube thumbnails in seconds.',
    icon: Frame,
    gradient: 'from-indigo-600 via-purple-600 to-pink-600',
    borderGlow: 'shadow-indigo-500/20',
  },
];

// Animation variants
const containerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
};

const itemVariants: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: 'easeOut' },
  },
};

const headerVariants: Variants = {
  hidden: { opacity: 0, y: -20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};

const ctaVariants: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { delay: 0.8, duration: 0.6 } },
};

// Helper function to get glow color for box-shadow
const getGlowColor = (borderGlow: string): string => {
  const glowColorMap: Record<string, string> = {
    'shadow-emerald-500/20': 'rgba(16, 185, 129, 0.3)',
    'shadow-purple-500/20': 'rgba(168, 85, 247, 0.3)',
    'shadow-blue-500/20': 'rgba(59, 130, 246, 0.3)',
    'shadow-pink-500/20': 'rgba(236, 72, 153, 0.3)',
    'shadow-orange-500/20': 'rgba(249, 115, 22, 0.3)',
    'shadow-indigo-500/20': 'rgba(99, 102, 241, 0.3)',
  };
  
  return glowColorMap[borderGlow] || 'rgba(168, 85, 247, 0.3)';
};

// Tool Card Component
interface ToolCardProps {
  tool: Tool;
  isHovered: boolean;
  onHover: (id: number | null) => void;
  onCardClick?: (toolId: number) => void;
}

const ToolCard: FC<ToolCardProps> = ({
  tool,
  isHovered,
  onHover,
  onCardClick,
}) => {
  const IconComponent = tool.icon;
  const glowColor = getGlowColor(tool.borderGlow);

  return (
    <motion.div
      variants={itemVariants}
      onMouseEnter={() => onHover(tool.id)}
      onMouseLeave={() => onHover(null)}
      onClick={() => onCardClick?.(tool.id)}
      className="group h-full cursor-pointer"
    >
      <motion.div
        animate={{
          y: isHovered ? -8 : 0,
        }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
        className={`relative h-full p-6 sm:p-8 rounded-2xl backdrop-blur-xl bg-white/5 border border-white/10 hover:border-white/20 transition-all duration-300 overflow-hidden group/card ${tool.borderGlow}`}
        style={{
          boxShadow: isHovered
            ? `0 0 40px ${glowColor}, 0 0 20px rgba(255, 255, 255, 0.05)`
            : '0 0 20px rgba(255, 255, 255, 0.02), 0 0 40px rgba(168, 85, 247, 0.1)',
        }}
      >
        {/* Gradient overlay effect on hover */}
        <div className="absolute inset-0 opacity-0 group-hover/card:opacity-100 transition-opacity duration-300 pointer-events-none">
          <div className={`absolute inset-0 bg-gradient-to-br ${tool.gradient} opacity-5`} />
        </div>

        {/* Animated border glow */}
        <div className="absolute inset-0 rounded-2xl opacity-0 group-hover/card:opacity-100 transition-opacity duration-300 pointer-events-none">
          <div
            className={`absolute inset-0 rounded-2xl opacity-20 blur-lg`}
            style={{
              background: `linear-gradient(to right, ${glowColor.replace('0.3', '0.5')}, transparent)`,
            }}
          />
        </div>

        {/* Content */}
        <div className="relative z-10">
          {/* Header with Icon and Badge */}
          <div className="flex items-start justify-between mb-6 sm:mb-8">
            <motion.div
              animate={{
                scale: isHovered ? 1.1 : 1,
                rotate: isHovered ? 5 : 0,
              }}
              transition={{ duration: 0.3 }}
              className={`p-3 sm:p-4 rounded-xl bg-gradient-to-br ${tool.gradient} shadow-lg`}
            >
              <IconComponent className="w-6 h-6 sm:w-7 sm:h-7 text-white" strokeWidth={1.5} />
            </motion.div>

            {tool.badge && (
              <motion.span
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
                className={`px-3 py-1 rounded-full text-xs sm:text-sm font-bold bg-gradient-to-r ${tool.badgeColor} text-white shadow-lg`}
              >
                {tool.badge}
              </motion.span>
            )}
          </div>

          {/* Title */}
          <h3 className="text-lg sm:text-xl font-bold text-white mb-3 group-hover/card:text-transparent group-hover/card:bg-clip-text group-hover/card:bg-gradient-to-r group-hover/card:from-cyan-400 group-hover/card:to-pink-400 transition-all duration-300">
            {tool.title}
          </h3>

          {/* Description */}
          <p className="text-purple-200/70 text-sm sm:text-base leading-relaxed group-hover/card:text-purple-200/90 transition-colors duration-300">
            {tool.description}
          </p>

          {/* Arrow indicator */}
          <motion.div
            animate={{
              opacity: isHovered ? 1 : 0,
              x: isHovered ? 4 : -4,
            }}
            transition={{ duration: 0.3 }}
            className="mt-6 sm:mt-8 flex items-center text-cyan-400 text-sm font-medium"
          >
            Try now
            <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </motion.div>
        </div>
      </motion.div>
    </motion.div>
  );
};

// Main Component
const CreativeToolsSection: FC<CreativeToolsSectionProps> = ({
  onToolClick,
  showCTA = true,
  animated = true,
}) => {
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);

  const handleToolClick = (toolId: number) => {
    onToolClick?.(toolId);
  };

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950 overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div
          className="absolute -top-40 -right-40 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse"
          style={{ animationDuration: '4s' }}
        />
        <div
          className="absolute -bottom-40 -left-40 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl animate-pulse"
          style={{ animationDuration: '6s' }}
        />
        <div
          className="absolute top-1/2 left-1/2 w-96 h-96 bg-pink-500/10 rounded-full blur-3xl animate-pulse"
          style={{ animationDuration: '5s' }}
        />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-24">
        {/* Header */}
        <motion.div
          variants={animated ? headerVariants : {}}
          initial={animated ? 'hidden' : undefined}
          animate={animated ? 'visible' : undefined}
          className="text-center mb-12 sm:mb-16 lg:mb-20"
        >
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-4 tracking-tight">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400">
              🧰 Creative Tools
            </span>
          </h2>
          <p className="text-lg sm:text-xl text-purple-200/80 max-w-2xl mx-auto leading-relaxed">
            A full kit of one-click AI utilities beyond generation.
          </p>
        </motion.div>

        {/* Tools Grid */}
        <motion.div
          variants={animated ? containerVariants : {}}
          initial={animated ? 'hidden' : undefined}
          animate={animated ? 'visible' : undefined}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8"
        >
          {TOOLS_CONFIG.map((tool) => (
            <ToolCard
              key={tool.id}
              tool={tool}
              isHovered={hoveredCard === tool.id}
              onHover={setHoveredCard}
              onCardClick={handleToolClick}
            />
          ))}
        </motion.div>

        {/* CTA Section */}
        {showCTA && (
          <motion.div
            variants={animated ? ctaVariants : {}}
            initial={animated ? 'hidden' : undefined}
            animate={animated ? 'visible' : undefined}
            className="mt-16 sm:mt-20 text-center"
          >
            <p className="text-purple-200/60 text-sm sm:text-base mb-6">
              ✨ More tools coming soon: Image-to-Video • Video Generation • Voice Synthesis • AI Music Generator • And more...
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-3 sm:px-10 sm:py-4 rounded-xl font-bold text-white bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 shadow-lg shadow-purple-500/50 hover:shadow-2xl hover:shadow-purple-500/75 transition-all duration-300"
            >
              Explore All Tools
            </motion.button>
          </motion.div>
        )}
      </div>

      {/* Floating particles effect styles */}
      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) translateX(0px); opacity: 0; }
          50% { opacity: 0.5; }
          100% { transform: translateY(-100px) translateX(20px); opacity: 0; }
        }
        
        .animate-float {
          animation: float 6s infinite ease-in;
        }
      `}</style>
    </div>
  );
};

export default CreativeToolsSection;

// Export types for external use
export type { Tool, CreativeToolsSectionProps, ToolCardProps };
export { TOOLS_CONFIG, ToolCard };
