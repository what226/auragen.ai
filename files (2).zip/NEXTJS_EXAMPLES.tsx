// Example 1: Simple Page (app/creative-tools/page.tsx)
import CreativeToolsSection from '@/components/CreativeToolsSection';

export const metadata = {
  title: 'Creative Tools | AI SaaS',
  description: 'Explore our full kit of one-click AI utilities beyond generation.',
};

export default function CreativeToolsPage() {
  return (
    <main className="min-h-screen">
      <CreativeToolsSection />
    </main>
  );
}

// ============================================
// Example 2: Full Page with Header & Footer (app/page.tsx)
import CreativeToolsSection from '@/components/CreativeToolsSection';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function HomePage() {
  return (
    <>
      <Header />
      <main>
        <CreativeToolsSection />
      </main>
      <Footer />
    </>
  );
}

// ============================================
// Example 3: With Navigation & Layout (app/layout.tsx)
'use client';

import type { ReactNode } from 'react';
import CreativeToolsSection from '@/components/CreativeToolsSection';

interface LayoutProps {
  children: ReactNode;
}

export default function RootLayout({ children }: LayoutProps) {
  return (
    <html lang="en">
      <body className="bg-slate-950">
        {/* Navigation - if needed */}
        <nav className="sticky top-0 z-50 bg-black/80 backdrop-blur-lg border-b border-white/10">
          {/* Nav content */}
        </nav>

        {/* Main Content */}
        {children}

        {/* Creative Tools Section */}
        <section id="creative-tools">
          <CreativeToolsSection />
        </section>

        {/* Footer */}
        <footer className="bg-black border-t border-white/10">
          {/* Footer content */}
        </footer>
      </body>
    </html>
  );
}

// ============================================
// Example 4: Dynamic Tool Loading with State Management
'use client';

import { useState, useEffect } from 'react';
import CreativeToolsSection from '@/components/CreativeToolsSection';

interface Tool {
  id: number;
  title: string;
  isAvailable: boolean;
}

export default function DynamicCreativeToolsPage() {
  const [tools, setTools] = useState<Tool[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Fetch available tools from your API
    const fetchTools = async () => {
      try {
        const response = await fetch('/api/tools');
        const data = await response.json();
        setTools(data);
      } catch (error) {
        console.error('Failed to fetch tools:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchTools();
  }, []);

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return <CreativeToolsSection />;
}

// ============================================
// Example 5: Component Wrapper with Custom Styling
'use client';

import CreativeToolsSection from '@/components/CreativeToolsSection';

interface CreativeToolsWrapperProps {
  showHeader?: boolean;
  showFooter?: boolean;
  customClassName?: string;
}

export default function CreativeToolsWrapper({
  showHeader = true,
  showFooter = true,
  customClassName = '',
}: CreativeToolsWrapperProps) {
  return (
    <div className={customClassName}>
      {showHeader && (
        <div className="text-center py-12 px-4">
          <h1 className="text-5xl font-bold text-white mb-4">
            Unleash Your Creativity
          </h1>
          <p className="text-xl text-purple-200/80">
            Powered by cutting-edge AI technology
          </p>
        </div>
      )}

      <CreativeToolsSection />

      {showFooter && (
        <div className="text-center py-12 px-4 border-t border-white/10">
          <p className="text-purple-200/60">
            © 2024 AI SaaS. All rights reserved.
          </p>
        </div>
      )}
    </div>
  );
}

// ============================================
// Example 6: Scroll-to Section Implementation
'use client';

import { useRef, useEffect, useState } from 'react';
import CreativeToolsSection from '@/components/CreativeToolsSection';

export default function PageWithScroll() {
  const toolsRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );

    if (toolsRef.current) {
      observer.observe(toolsRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <main>
      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-6xl font-bold text-white mb-4">
            Welcome to AI SaaS
          </h1>
          <button 
            onClick={() => toolsRef.current?.scrollIntoView({ behavior: 'smooth' })}
            className="mt-8 px-8 py-3 bg-purple-600 hover:bg-purple-700 rounded-lg text-white font-bold"
          >
            Explore Tools
          </button>
        </div>
      </section>

      {/* Creative Tools Section */}
      <div ref={toolsRef}>
        {isVisible && <CreativeToolsSection />}
      </div>
    </main>
  );
}

// ============================================
// Example 7: With Modal for Tool Details
'use client';

import { useState } from 'react';
import CreativeToolsSection from '@/components/CreativeToolsSection';

interface ToolDetail {
  id: number;
  title: string;
  fullDescription: string;
  features: string[];
  pricing: string;
}

export default function CreativeToolsWithModal() {
  const [selectedTool, setSelectedTool] = useState<ToolDetail | null>(null);

  const toolDetails: ToolDetail[] = [
    {
      id: 1,
      title: 'Background Remover',
      fullDescription: 'Cut any subject out cleanly with one click using advanced AI.',
      features: ['One-click removal', 'Transparent PNG export', 'Batch processing'],
      pricing: 'Free tier available',
    },
    // Add other tool details...
  ];

  return (
    <>
      <CreativeToolsSection />

      {/* Modal */}
      {selectedTool && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-slate-900 border border-white/10 rounded-2xl p-8 max-w-md w-full mx-4">
            <h2 className="text-2xl font-bold text-white mb-4">{selectedTool.title}</h2>
            <p className="text-purple-200/80 mb-4">{selectedTool.fullDescription}</p>
            
            <div className="mb-6">
              <h3 className="font-bold text-white mb-2">Features:</h3>
              <ul className="text-purple-200/80 text-sm space-y-1">
                {selectedTool.features.map((feature, i) => (
                  <li key={i}>✓ {feature}</li>
                ))}
              </ul>
            </div>

            <div className="flex gap-4">
              <button
                onClick={() => setSelectedTool(null)}
                className="flex-1 px-4 py-2 border border-white/10 rounded-lg text-white hover:bg-white/5"
              >
                Close
              </button>
              <button className="flex-1 px-4 py-2 bg-purple-600 rounded-lg text-white hover:bg-purple-700">
                Try Now
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// ============================================
// Example 8: Analytics & Event Tracking
'use client';

import { useCallback } from 'react';
import CreativeToolsSection from '@/components/CreativeToolsSection';

export default function CreativeToolsWithAnalytics() {
  const trackEvent = useCallback((toolName: string, action: string) => {
    // Send to analytics service (Google Analytics, Mixpanel, etc.)
    console.log(`Event: ${action} - ${toolName}`);
    
    if (typeof gtag !== 'undefined') {
      gtag('event', action, {
        'tool_name': toolName,
        'category': 'creative_tools',
      });
    }
  }, []);

  const handleToolClick = useCallback((toolId: number) => {
    const toolNames = {
      1: 'Background Remover',
      2: 'Image Upscaler',
      3: 'Face Swap',
      4: 'AI Avatar Generator',
      5: 'AI Logo Generator',
      6: 'Thumbnail Generator',
    };
    
    trackEvent(toolNames[toolId as keyof typeof toolNames], 'tool_click');
  }, [trackEvent]);

  return (
    <main>
      <CreativeToolsSection />
      {/* Attach handleToolClick to your tools */}
    </main>
  );
}
