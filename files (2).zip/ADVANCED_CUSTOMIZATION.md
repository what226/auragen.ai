# Advanced Customization & Theme Variants

## Custom Configuration

### Creating Custom Themes

#### Theme 1: Cyberpunk Neon (Dark)
```jsx
const cyberpunkTheme = {
  background: 'from-slate-900 via-black to-slate-900',
  textPrimary: 'text-cyan-300',
  textSecondary: 'text-cyan-200/70',
  accentGradient: 'from-cyan-500 via-blue-500 to-purple-500',
  cardBg: 'bg-black/40',
  cardBorder: 'border-cyan-500/30',
};
```

#### Theme 2: Minimal Light
```jsx
const minimalistTheme = {
  background: 'from-white via-gray-50 to-white',
  textPrimary: 'text-gray-900',
  textSecondary: 'text-gray-600',
  accentGradient: 'from-blue-600 via-purple-600 to-pink-600',
  cardBg: 'bg-white',
  cardBorder: 'border-gray-200',
};
```

#### Theme 3: Sunset Gold (Warm)
```jsx
const sunsetTheme = {
  background: 'from-orange-950 via-red-950 to-purple-950',
  textPrimary: 'text-orange-100',
  textSecondary: 'text-orange-200/70',
  accentGradient: 'from-orange-400 via-red-400 to-pink-400',
  cardBg: 'bg-orange-900/20',
  cardBorder: 'border-orange-500/30',
};
```

### Implementing Custom Themes

```jsx
'use client';

import React, { createContext, useContext, ReactNode } from 'react';
import CreativeToolsSection from '@/components/CreativeToolsSection';

interface Theme {
  background: string;
  textPrimary: string;
  textSecondary: string;
  accentGradient: string;
  cardBg: string;
  cardBorder: string;
}

const ThemeContext = createContext<Theme | null>(null);

export function ThemeProvider({ 
  children, 
  theme 
}: { 
  children: ReactNode; 
  theme: Theme; 
}) {
  return (
    <ThemeContext.Provider value={theme}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
}

// Usage
const cyberpunkTheme = { /* ... */ };

export default function App() {
  return (
    <ThemeProvider theme={cyberpunkTheme}>
      <CreativeToolsSection />
    </ThemeProvider>
  );
}
```

## Advanced Animation Customization

### Custom Stagger Timing
```jsx
// Faster stagger effect
const fastContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,  // Reduce from 0.1
      delayChildren: 0.1,      // Reduce from 0.2
    },
  },
};

// Slower, more dramatic stagger
const dramaticContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,    // Increase from 0.1
      delayChildren: 0.3,      // Increase from 0.2
    },
  },
};
```

### Custom Hover Effects
```jsx
// Pop effect on hover
const popVariant = {
  initial: { scale: 1 },
  hover: { scale: 1.15, rotate: 2 },
};

// Subtle float effect
const floatVariant = {
  initial: { y: 0 },
  hover: { y: -12 },
};

// Glow pulse effect
const glowVariant = {
  initial: { filter: 'drop-shadow(0 0 0px rgba(168, 85, 247, 0))' },
  hover: {
    filter: 'drop-shadow(0 0 20px rgba(168, 85, 247, 0.5))',
  },
};
```

### Staggered Glow Animation
```jsx
const StaggeredGlowCard = ({ tool, isHovered }) => {
  return (
    <motion.div
      animate={{
        boxShadow: isHovered
          ? [
              `0 0 20px rgba(168, 85, 247, 0.2)`,
              `0 0 40px rgba(168, 85, 247, 0.4)`,
              `0 0 20px rgba(168, 85, 247, 0.2)`,
            ]
          : '0 0 20px rgba(255, 255, 255, 0.02)',
      }}
      transition={{
        duration: 2,
        repeat: isHovered ? Infinity : 0,
      }}
    >
      {/* Card content */}
    </motion.div>
  );
};
```

## Layout Customization

### Custom Grid Layouts

#### 2-Column Layout (Mobile-First)
```jsx
<div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
  {tools.map((tool) => (
    <ToolCard key={tool.id} tool={tool} />
  ))}
</div>
```

#### 4-Column Layout (Premium Display)
```jsx
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
  {tools.map((tool) => (
    <ToolCard key={tool.id} tool={tool} />
  ))}
</div>
```

#### Masonry Layout
```jsx
<div className="columns-1 sm:columns-2 lg:columns-3 gap-6">
  {tools.map((tool) => (
    <div key={tool.id} className="break-inside-avoid mb-6">
      <ToolCard tool={tool} />
    </div>
  ))}
</div>
```

## Data Configuration

### Extended Tool Properties
```tsx
interface ExtendedTool extends Tool {
  category?: string;
  difficulty?: 'Beginner' | 'Intermediate' | 'Advanced';
  tags?: string[];
  rating?: number;
  popularity?: number;
  isPremium?: boolean;
  isNew?: boolean;
  demoUrl?: string;
  tutorialUrl?: string;
  features?: string[];
  pricing?: {
    free?: boolean;
    pro?: number;
    enterprise?: number;
  };
}

// Example
const advancedTools: ExtendedTool[] = [
  {
    id: 1,
    title: 'Background Remover',
    description: '...',
    icon: Scissors,
    badge: 'LIVE',
    badgeColor: 'from-emerald-500 to-teal-500',
    gradient: 'from-emerald-600 via-teal-600 to-cyan-600',
    borderGlow: 'shadow-emerald-500/20',
    category: 'Image Editing',
    difficulty: 'Beginner',
    tags: ['image', 'editing', 'ai', 'fast'],
    rating: 4.8,
    popularity: 95,
    isPremium: false,
    features: [
      'One-click removal',
      'Transparent background',
      'Batch processing',
      'High resolution support',
    ],
    pricing: {
      free: true,
      pro: 9.99,
    },
  },
];
```

### Tool Filtering System
```jsx
'use client';

import { useState } from 'react';
import CreativeToolsSection from '@/components/CreativeToolsSection';

export default function FilteredToolsPage() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showPremiumOnly, setShowPremiumOnly] = useState(false);

  const filteredTools = TOOLS_CONFIG.filter((tool) => {
    if (selectedCategory && tool.category !== selectedCategory) return false;
    if (showPremiumOnly && !tool.isPremium) return false;
    return true;
  });

  return (
    <div>
      {/* Filter Controls */}
      <div className="flex gap-4 mb-8">
        <select
          value={selectedCategory || ''}
          onChange={(e) => setSelectedCategory(e.target.value || null)}
          className="px-4 py-2 bg-slate-800 text-white rounded-lg border border-white/10"
        >
          <option value="">All Categories</option>
          <option value="Image Editing">Image Editing</option>
          <option value="Video">Video</option>
          <option value="Audio">Audio</option>
        </select>

        <label className="flex items-center gap-2 text-white">
          <input
            type="checkbox"
            checked={showPremiumOnly}
            onChange={(e) => setShowPremiumOnly(e.target.checked)}
          />
          Premium Only
        </label>
      </div>

      {/* Tools Grid */}
      <CreativeToolsSection />
    </div>
  );
}
```

## Performance Optimization Strategies

### Lazy Loading Cards
```jsx
'use client';

import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

interface LazyToolCardProps {
  tool: Tool;
  index: number;
}

export function LazyToolCard({ tool, index }: LazyToolCardProps) {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );

    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={ref}>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.05 }}
        >
          <ToolCard tool={tool} />
        </motion.div>
      )}
    </div>
  );
}
```

### Image Optimization
```jsx
import Image from 'next/image';

interface ToolCardWithImageProps {
  tool: Tool;
  imageSrc: string;
}

export function ToolCardWithImage({ tool, imageSrc }: ToolCardWithImageProps) {
  return (
    <div className="relative">
      <Image
        src={imageSrc}
        alt={tool.title}
        width={400}
        height={300}
        loading="lazy"
        quality={75}
        className="rounded-xl mb-4"
      />
      <ToolCard tool={tool} />
    </div>
  );
}
```

### Memoization for Performance
```jsx
import { memo, useMemo } from 'react';

const MemoizedToolCard = memo(
  ({ tool, isHovered, onHover }: ToolCardProps) => (
    <ToolCard tool={tool} isHovered={isHovered} onHover={onHover} />
  ),
  (prevProps, nextProps) => {
    return (
      prevProps.tool.id === nextProps.tool.id &&
      prevProps.isHovered === nextProps.isHovered
    );
  }
);

const MemoizedCreativeToolsSection = memo(CreativeToolsSection);

export default MemoizedCreativeToolsSection;
```

## Integration Patterns

### With Backend API
```jsx
'use client';

import { useEffect, useState } from 'react';
import CreativeToolsSection from '@/components/CreativeToolsSection';

interface ToolFromAPI extends Tool {
  availability: 'available' | 'beta' | 'coming_soon';
  usageCount: number;
}

export default function DynamicToolsPage() {
  const [tools, setTools] = useState<ToolFromAPI[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchTools = async () => {
      try {
        const response = await fetch('/api/tools', {
          cache: 'revalidate',
          next: { revalidate: 3600 }, // Revalidate every hour
        });
        const data = await response.json();
        setTools(data);
      } catch (error) {
        console.error('Failed to fetch tools:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchTools();
  }, []);

  if (isLoading) return <LoadingSkeletons />;

  return <CreativeToolsSection />;
}
```

### With State Management (Zustand)
```jsx
import { create } from 'zustand';

interface ToolsStore {
  tools: Tool[];
  selectedTool: Tool | null;
  selectTool: (tool: Tool) => void;
  deselectTool: () => void;
  addTool: (tool: Tool) => void;
  removeTool: (toolId: number) => void;
}

export const useToolsStore = create<ToolsStore>((set) => ({
  tools: TOOLS_CONFIG,
  selectedTool: null,
  selectTool: (tool) => set({ selectedTool: tool }),
  deselectTool: () => set({ selectedTool: null }),
  addTool: (tool) =>
    set((state) => ({ tools: [...state.tools, tool] })),
  removeTool: (toolId) =>
    set((state) => ({
      tools: state.tools.filter((t) => t.id !== toolId),
    })),
}));

// Usage in component
function ToolSelector() {
  const { tools, selectedTool, selectTool } = useToolsStore();

  return (
    <div>
      {tools.map((tool) => (
        <button
          key={tool.id}
          onClick={() => selectTool(tool)}
          className={selectedTool?.id === tool.id ? 'selected' : ''}
        >
          {tool.title}
        </button>
      ))}
    </div>
  );
}
```

## Accessibility Enhancements

### Keyboard Navigation
```jsx
'use client';

import { useEffect, useState, useRef } from 'react';

export function AccessibleToolsSection() {
  const [focusedIndex, setFocusedIndex] = useState(-1);
  const toolsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') {
        setFocusedIndex((prev) =>
          prev < toolsRef.current.length - 1 ? prev + 1 : prev
        );
      } else if (e.key === 'ArrowLeft') {
        setFocusedIndex((prev) => (prev > 0 ? prev - 1 : prev));
      } else if (e.key === 'Enter' && focusedIndex >= 0) {
        // Handle selection
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [focusedIndex]);

  return (
    <div role="grid" aria-label="Creative tools grid">
      {TOOLS_CONFIG.map((tool, index) => (
        <div
          key={tool.id}
          ref={(el) => {
            if (el) toolsRef.current[index] = el;
          }}
          tabIndex={focusedIndex === index ? 0 : -1}
          role="gridcell"
          aria-label={tool.title}
        >
          <ToolCard tool={tool} />
        </div>
      ))}
    </div>
  );
}
```

### Screen Reader Announcements
```jsx
import { useEffect } from 'react';

export function ScreenReaderAnnouncement({ message }: { message: string }) {
  useEffect(() => {
    // Create a live region for screen reader announcements
    const announcement = document.createElement('div');
    announcement.setAttribute('role', 'status');
    announcement.setAttribute('aria-live', 'polite');
    announcement.setAttribute('aria-atomic', 'true');
    announcement.className = 'sr-only';
    announcement.textContent = message;
    
    document.body.appendChild(announcement);
    
    return () => {
      document.body.removeChild(announcement);
    };
  }, [message]);

  return null;
}
```

## Testing Strategies

### Unit Tests (Jest + React Testing Library)
```jsx
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import CreativeToolsSection from '@/components/CreativeToolsSection';

describe('CreativeToolsSection', () => {
  it('renders all 6 tools', () => {
    render(<CreativeToolsSection />);
    const tools = screen.getAllByRole('article');
    expect(tools).toHaveLength(6);
  });

  it('shows hover state on tool card', async () => {
    render(<CreativeToolsSection />);
    const card = screen.getByText('Background Remover');
    
    await userEvent.hover(card.closest('[role="article"]')!);
    
    expect(card).toHaveClass('group-hover/card:text-transparent');
  });

  it('calls onToolClick when tool is clicked', async () => {
    const handleClick = jest.fn();
    render(<CreativeToolsSection onToolClick={handleClick} />);
    
    await userEvent.click(screen.getByText('Image Upscaler'));
    
    expect(handleClick).toHaveBeenCalledWith(2);
  });
});
```

### E2E Tests (Cypress)
```javascript
describe('Creative Tools Section', () => {
  beforeEach(() => {
    cy.visit('/creative-tools');
  });

  it('displays all tools on page load', () => {
    cy.get('[role="gridcell"]').should('have.length', 6);
  });

  it('applies hover state on tool card', () => {
    cy.get('[role="gridcell"]').first().trigger('mouseenter');
    cy.get('[role="gridcell"]').first().should('have.css', 'transform');
  });

  it('navigates to tool detail on click', () => {
    cy.get('[role="gridcell"]').first().click();
    cy.url().should('include', '/tools/1');
  });
});
```
